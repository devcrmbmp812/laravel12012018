import {Youtube} from './Youtube';

export class ExternalServices {
    constructor() {
        new Youtube();
    }
}