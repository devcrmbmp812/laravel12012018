let ExternalServiceConfig = {
    youtube: {
        api_key: "AIzaSyCV4fmfdgsValGNR3sc-0W3cbpEZ8uOd60"
    }
};

export {ExternalServiceConfig};
