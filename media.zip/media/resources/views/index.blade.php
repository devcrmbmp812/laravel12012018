{!! RvMedia::renderHeader() !!}
{!! RvMedia::renderContent() !!}
{!! RvMedia::renderFooter() !!}